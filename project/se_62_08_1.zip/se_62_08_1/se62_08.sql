-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2020 at 05:35 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se62_08`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrowingrights`
--

CREATE TABLE `borrowingrights` (
  `ELID` int(11) NOT NULL,
  `UTID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `borrowingrights`
--

INSERT INTO `borrowingrights` (`ELID`, `UTID`) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 1),
(2, 2),
(2, 3),
(3, 1),
(3, 2),
(3, 3),
(4, 1),
(4, 2),
(4, 3),
(6, 2),
(7, 2),
(7, 3),
(8, 2),
(8, 3);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `CID` int(11) NOT NULL,
  `CName` varchar(50) NOT NULL,
  `isDelete` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CID`, `CName`, `isDelete`) VALUES
(1, 'คอมพิวเตอร์', 0),
(2, 'อิเล็กทรอนิกส์', 0),
(3, 'อุปกรณ์ทั่วไป', 0),
(4, 'อุปกรณ์ไฟฟ้า', 0),
(5, 'อุปกรณ์ฮาร์ดแวร์', 1),
(6, 'อุปกรณ์เน็ตเวิร์ค', 0);

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `config_key` varchar(255) NOT NULL,
  `coonfig_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`config_key`, `coonfig_value`) VALUES
('day_cancelapprove', '3'),
('tel', '0859999999'),
('email', 'se62_08@gmail.com'),
('time', '03.00');

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `EID` int(11) NOT NULL,
  `ELID` int(11) NOT NULL,
  `SNumber` varchar(50) DEFAULT NULL,
  `EStatus` enum('สามารถยืมได้','กำลังถูกยืม','เสียหาย','กำลังซ่อมแซม') NOT NULL,
  `isDelete` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`EID`, `ELID`, `SNumber`, `EStatus`, `isDelete`) VALUES
(1, 1, 'E0163-10000000001/59', 'กำลังถูกยืม', 0),
(2, 2, NULL, 'กำลังถูกยืม', 0),
(3, 3, NULL, 'สามารถยืมได้', 0),
(4, 4, NULL, 'สามารถยืมได้', 0),
(5, 6, 'E0163-40000000078/58', 'กำลังซ่อมแซม', 0),
(6, 7, 'E0163-60000000023/58', 'สามารถยืมได้', 0),
(7, 8, 'E0163-60000000033/59', 'สามารถยืมได้', 0),
(8, 1, 'E0163-10000000002/59', 'สามารถยืมได้', 0),
(9, 2, NULL, 'กำลังถูกยืม', 0),
(10, 2, NULL, 'กำลังถูกยืม', 0),
(11, 3, NULL, 'สามารถยืมได้', 0),
(12, 5, 'E0163-10000000111/60', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `equipmentlist`
--

CREATE TABLE `equipmentlist` (
  `ELID` int(11) NOT NULL,
  `CID` int(11) NOT NULL,
  `EName` varchar(50) NOT NULL,
  `Brand` varchar(50) NOT NULL,
  `Detail` text NOT NULL,
  `ELStatus` enum('ยืมได้','ยืมไม่ได้') NOT NULL,
  `isDelete` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `equipmentlist`
--

INSERT INTO `equipmentlist` (`ELID`, `CID`, `EName`, `Brand`, `Detail`, `ELStatus`, `isDelete`) VALUES
(1, 1, 'เมาส์', 'logitech', '- USB 2.0\r\n- 1000 dpi\r\n- 3 buttoms\r\n- optical mouse', 'ยืมได้', 0),
(2, 2, 'ไดโอดตัวเรียงกระแส ', 'New and High Quality', '-3A 1000V DO-27\r\n-10 PCS HER308 HER 308 Rectifier Ultra Fast Recovery Diode 3A 1000V DO-27', 'ยืมได้', 0),
(3, 4, 'ปลั๊กไฟ 4 ช่อง 1 สวิทซ์ 3 เมตร', 'DATA  ', '-ปลั๊กไฟ 4 ช่อง 1 สวิทซ์ 3 เมตร\r\n-ความกว้าง 17 เซนติเมตร\r\n-ความยาว	41.5 เซนติเมตร\r\n-ความสูง 5 เซนติเมตร\r\n-สีขาว\r\n', 'ยืมได้', 0),
(4, 3, 'กุญแจห้องเก็บของ', 'TRI-CIRCLE', '- ไม่เป็นสนิม', 'ยืมได้', 0),
(5, 1, 'Macmini7,1', 'Apple', '- รองรับจอมอนิเตอร์ได้ 2 จอ ความละเอียดที่ 2560 x 1600 pixels ผ่านพอร์ต Thunderbolt 2\r\n- รองรับจอมอนิเตอร์ขนาด 4K ความละเอียด 4096 x 2160 ที่ 24Hz ผ่านช่องต่อ HDMI', 'ยืมไม่ได้', 0),
(6, 4, 'ออสซิลโลสโคป รุ่น SDS7102', 'OWON ', '-ออสซิลโลสโคปแบบ 2+1 แชนแนล\r\n-แบนด์วิดธ์ 100MHz\r\n-Sample Rate 1GS/s\r\n-สามารถเชื่อมต่อผ่านระบบ LAN\r\n-เชื่อมต่อกับคอมพิวเตอร์ผ่าน USB พร้อซอฟต์แวร์', 'ยืมได้', 0),
(7, 6, 'Switch SG350-28MP', 'Cisco', '-28-Port \r\n-Gigabit 10/100/1000 \r\n-PoE+ 382W\r\n-2x1G SFP/RJ-45\r\n-2x1G SFP', 'ยืมได้', 0),
(8, 6, 'Router Cisco 2 Ports', 'Cisco', ' - 2 Ports\r\n - Management Port\r\n - 6 Slots\r\n - Gigabit Ethernet\r\n - 1U\r\n - Rack-mountable', 'ยืมได้', 0);

-- --------------------------------------------------------

--
-- Table structure for table `orderdetail`
--

CREATE TABLE `orderdetail` (
  `OID` int(11) NOT NULL,
  `EID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderdetail`
--

INSERT INTO `orderdetail` (`OID`, `EID`) VALUES
(1, 6),
(2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orderitem`
--

CREATE TABLE `orderitem` (
  `OID` int(11) NOT NULL,
  `RID` int(11) NOT NULL,
  `getStaffID` int(11) NOT NULL,
  `getTime` int(11) NOT NULL,
  `getDate` date NOT NULL,
  `returnStaffID` int(11) DEFAULT NULL,
  `returnTime` int(11) DEFAULT NULL,
  `returnDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderitem`
--

INSERT INTO `orderitem` (`OID`, `RID`, `getStaffID`, `getTime`, `getDate`, `returnStaffID`, `returnTime`, `returnDate`) VALUES
(1, 2, 6, 1583819277, '2020-03-10', 6, 1584172077, '2020-03-14'),
(2, 6, 6, 1582602477, '2020-02-25', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `requestform`
--

CREATE TABLE `requestform` (
  `reqID` int(11) NOT NULL,
  `UID` int(11) NOT NULL,
  `Time` datetime NOT NULL,
  `Detail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `requestform`
--

INSERT INTO `requestform` (`reqID`, `UID`, `Time`, `Detail`) VALUES
(2, 1, '2020-02-29 10:00:00', 'อยากให้ห้องเรียนเปลี่ยนคีย์บอร์ดใหม่');

-- --------------------------------------------------------

--
-- Table structure for table `requirement`
--

CREATE TABLE `requirement` (
  `RID` int(11) NOT NULL,
  `UID` int(11) NOT NULL,
  `ProfessorID` int(11) DEFAULT NULL,
  `AcceptTime` datetime DEFAULT NULL,
  `ReqTime` int(11) NOT NULL,
  `ReqDate` date NOT NULL,
  `Reason` text NOT NULL,
  `RStatus` enum('รอยืนยัน','ยืนยันแล้ว','รับอุปกรณ์แล้ว','ยกเลิก') NOT NULL,
  `DetailCancel` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `requirement`
--

INSERT INTO `requirement` (`RID`, `UID`, `ProfessorID`, `AcceptTime`, `ReqTime`, `ReqDate`, `Reason`, `RStatus`, `DetailCancel`) VALUES
(1, 2, 5, '2020-03-23 10:08:10', 1583118057, '2020-03-02', 'ทำโปรเจค', 'ยืนยันแล้ว', NULL),
(2, 7, NULL, '2020-03-10 13:13:00', 1583802057, '2020-03-10', 'นำไปสอนนักศึกษา', 'รับอุปกรณ์แล้ว', NULL),
(3, 4, 5, NULL, 1585148457, '2020-03-25', 'ใช้เปิดห้องเก็บของ', 'รอยืนยัน', NULL),
(4, 4, 5, NULL, 1583326857, '2020-03-04', 'เมาส์หาย, นำไปทำงาน', 'ยกเลิก', 'หาเมาส์เจอแล้ว'),
(5, 3, 5, '2020-02-18 16:12:00', 1581581757, '2020-02-13', 'ทำงาน', 'รับอุปกรณ์แล้ว', NULL),
(6, 1, 5, '2020-02-24 09:16:17', 1582370157, '2020-02-22', 'ทำการบ้าน', 'รับอุปกรณ์แล้ว', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `requirementdetail`
--

CREATE TABLE `requirementdetail` (
  `RID` int(11) NOT NULL,
  `ELID` int(11) NOT NULL,
  `Amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `requirementdetail`
--

INSERT INTO `requirementdetail` (`RID`, `ELID`, `Amount`) VALUES
(1, 2, 3),
(2, 3, 2),
(2, 7, 1),
(3, 4, 1),
(4, 1, 1),
(5, 3, 3),
(6, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UID` int(11) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `UTID` int(11) NOT NULL,
  `Title` varchar(10) NOT NULL,
  `FName` varchar(50) NOT NULL,
  `LName` varchar(50) NOT NULL,
  `GMail` varchar(50) NOT NULL,
  `isDelete` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UID`, `Username`, `UTID`, `Title`, `FName`, `LName`, `GMail`, `isDelete`) VALUES
(1, 'b6020501469', 1, 'นางสาว', 'อัญธิกา', 'วงเทียนทอง', 'aunthika.w@ku.th', 0),
(2, 'b6020503798', 1, 'นางสาว', 'ธนพร', 'รุ่งวิทยานนท์', 'thanaporn.run@ku.th', 0),
(3, 'b6020501353', 1, 'นางสาว', 'นรารัตน์', 'ตั้งแก้ว', 'nararat.t@ku.th', 0),
(4, 'b6020501442', 1, 'นาย', 'โสภณ', 'โตใหญ่', 'sopon.to@ku.th', 0),
(5, 'fengncn', 2, 'นางสาว', 'นุชนาฎ', 'สัตยากวี', 'fengncn@ku.ac.th', 0),
(6, 'fengsstc', 3, 'นางสาว', 'ศศิธร', 'ชลรัตน์อมฤต', 'fengsstc@ku.ac.th', 0),
(7, 'fengbyr', 2, 'นางสาว', 'บุญรัตน์', 'เผดิมรอด', 'boonyarat.p@ku.th', 0);

-- --------------------------------------------------------

--
-- Table structure for table `usertype`
--

CREATE TABLE `usertype` (
  `UTID` int(11) NOT NULL,
  `UTName` varchar(50) NOT NULL,
  `UTNote` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usertype`
--

INSERT INTO `usertype` (`UTID`, `UTName`, `UTNote`) VALUES
(1, 'นิสิต', 'นิสิตม.เกษตรศาสตร์ กำแพงแสน ภาควิชาวิศวกรรมคอมพิวเตอร์'),
(2, 'อาจารย์', 'อาจารย์ม.เกษตรศาสตร์ กำแพงแสน ภาควิชาวิศวกรรมคอมพิวเตอร์'),
(3, 'เจ้าหน้าที่', 'เจ้าหน้าม.เกษตรศาสตร์ กำแพงแสน ภาควิชาวิศวกรรมคอมพิวเตอร์');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `borrowingrights`
--
ALTER TABLE `borrowingrights`
  ADD PRIMARY KEY (`ELID`,`UTID`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CID`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`EID`);

--
-- Indexes for table `equipmentlist`
--
ALTER TABLE `equipmentlist`
  ADD PRIMARY KEY (`ELID`);

--
-- Indexes for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD PRIMARY KEY (`OID`,`EID`);

--
-- Indexes for table `orderitem`
--
ALTER TABLE `orderitem`
  ADD PRIMARY KEY (`OID`);

--
-- Indexes for table `requestform`
--
ALTER TABLE `requestform`
  ADD PRIMARY KEY (`reqID`);

--
-- Indexes for table `requirement`
--
ALTER TABLE `requirement`
  ADD PRIMARY KEY (`RID`);

--
-- Indexes for table `requirementdetail`
--
ALTER TABLE `requirementdetail`
  ADD PRIMARY KEY (`RID`,`ELID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UID`);

--
-- Indexes for table `usertype`
--
ALTER TABLE `usertype`
  ADD PRIMARY KEY (`UTID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `CID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `EID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `equipmentlist`
--
ALTER TABLE `equipmentlist`
  MODIFY `ELID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orderitem`
--
ALTER TABLE `orderitem`
  MODIFY `OID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `requestform`
--
ALTER TABLE `requestform`
  MODIFY `reqID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `requirement`
--
ALTER TABLE `requirement`
  MODIFY `RID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `usertype`
--
ALTER TABLE `usertype`
  MODIFY `UTID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
