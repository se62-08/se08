<?php $__env->startSection('title',"test01"); ?>
<?php $__env->startSection('Content'); ?>
    <h4>tel 0625424005 </h4>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('./layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\SEProject\resources\views/test.blade.php ENDPATH**/ ?>