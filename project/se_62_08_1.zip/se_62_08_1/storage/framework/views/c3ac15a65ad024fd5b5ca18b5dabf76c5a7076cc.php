<?php $__env->startSection('title',"Comment"); ?>
<?php $__env->startSection('CSS'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Content'); ?>
    
    
    <div class="row">
        <div class="col-xl-12 col-12 mb-4">
            <div class="card">
                <div class="card-header card-bg " style="background-color: #bf4040">
                    <span class="link-active" style="font-size: 18px; color:white;">แสดงความคิดเห็น</span>
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="card shadow mb-4">
        <div class="card-header py-3" style="background-color: #bf4040">
            <span class="link-active" style="font-size: 17px; color:white">ข้อเสนอแนะ</span>
        </div>
        <div class="card-body" id="AddBody">
            <div class="container">
                <form method="POST" action="comment">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="col-sm-12 col-md-12">
                        <div>
                            <textarea rows="6" cols="50" id = "detailComment" name="detailComment" class="form-control form-control-sm-5"></textarea><br>
                        </div>
                    </div>
                    
                    <?php for($i=0; $i<count($TableComment); $i++): ?>
                        <div style="margin-left:93%">
                            <button type="submit" id ="detailComment_1" class="btn btn-success btn-xl tt btnsend" uid="<?php echo e($TableComment[$i]->UID); ?>" nDetail="<?php echo e($TableComment[$i]->Detail); ?>" token="<?php echo e(csrf_token()); ?>" data-toggle="tooltip" title='ส่งข้อเสนอแนะ'><i class="fas fa-paper-plane"></i> ส่ง</button>
                        </div>
                    <?php endfor; ?>
                </form>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Javascript'); ?>
<script>
    $(document).ready(function() {
       $(".btnsend").click(function() {
            var name = $(this).attr('nDetail')
            var id = $(this).attr('uid')
            var token = $(this).attr('token')
                swal({
                    title: "คุณต้องการส่งข้อเสนอแนะหรือไม่?",
                    icon: "warning",
                    buttons: true,
                    buttons: ["ยกเลิก", "ยืนยัน"],
                    dangerMode: true,
                })
                .then((willSend) => {
                    if (willSend) {
                        $.ajax({
                            url: 'comment',
                            type: 'post',
                            async : false, //เวลาส่งค่าจะรอจนกว่าจะส่งค่ากลับมา
                            data:{
                                // _method:'post',
                                _token:token,
                                UID:id
                            },
                            success: function(result) {
                                swal("ส่งข้อความสำเร็จ", {
                                    icon: "success",
                                    buttons: false
                                });
                                setTimeout(function() {
                                    window.location.replace("commemt"); //โหลดหน้าเดิม
                                }, 1500);
                            },
                            error: function (xhr, ajaxOptions, thrownError) {
                                alert(xhr.status);
                                alert(thrownError);
                            }
                        });
                    } else {
                        swal("ส่งข้อความไม่สำเร็จ",{
                            icon: "error",
                            buttons: false
                        });
                        setTimeout(function() {
                            swal.close();
                        }, 1500);
                    }
                });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(Session::get('userType')==1 ? "./layoutNisit" : (Session::get('userType')==2 ?"./layoutTeacher":"./layoutAdmin"), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\SEProject\resources\views/comment.blade.php ENDPATH**/ ?>