<link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet">

<?php /**PATH D:\xampp\htdocs\SEProject\resources\views/test2.blade.php ENDPATH**/ ?>