<?php $__env->startSection('title',"test01"); ?>
<?php $__env->startSection('Content'); ?>
    <h1>tel 0625424005 </h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('./layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\SEProject\resources\views////test/test.blade.php ENDPATH**/ ?>